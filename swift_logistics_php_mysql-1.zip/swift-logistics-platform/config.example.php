<?php
// Copy this file to config.php and fill in your database details.
// Keep config.php private and never upload it to a public repository.
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'swift_logistics',
        'user' => 'YOUR_DATABASE_USER',
        'pass' => 'YOUR_DATABASE_PASSWORD',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'name' => 'Swift Logistics Global',
        'base_url' => '', // Example: https://yourdomain.com (no trailing slash)
        'timezone' => 'UTC',
    ],
];
