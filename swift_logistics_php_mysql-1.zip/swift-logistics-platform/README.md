# Swift Logistics Global — PHP + MySQL starter platform

This project turns the static logistics site into a PHP/MySQL website with a public tracking lookup, quote/contact forms stored in MySQL, and a protected admin area for creating shipments and adding tracking events.

## Requirements
- PHP 8.1+ (8.2+ recommended)
- MySQL 8+ or compatible MariaDB
- PHP extensions: `pdo_mysql`
- HTTPS for production

## Files
- `public/` — web document root (recommended)
- `includes/bootstrap.php` — PDO connection, session, helpers, CSRF
- `database/schema.sql` — database tables
- `database/create_admin.php` — CLI-only administrator creation script
- `config.example.php` — copy to `config.php` and configure

## Install on cPanel hosting
1. Create a MySQL database and a database user in cPanel. Grant the user all privileges on that database.
2. Import `database/schema.sql` using phpMyAdmin. If your hosting account requires a prefixed database name, edit the `CREATE DATABASE` / `USE` lines or create the tables in your selected database manually.
3. Copy `config.example.php` to `config.php` in the project root. Enter the exact database host, database name, username, and password provided by your host. Set the timezone you want, for example `America/Chicago` for Houston or `UTC`.
4. Recommended: set the domain's document root to the project's `public/` folder so `config.php`, `includes/`, and `database/` are not publicly accessible. If your host does not let you change document root, ask the host to configure it or move private files above `public_html` and adjust paths.
5. Create the first admin from a terminal/SSH session at the project root:
   `php database/create_admin.php`
   Use a unique email and a password of at least 12 characters. If you do not have terminal access, do not make the script web-accessible; ask your hosting provider to run it or create an admin securely through a one-time private CLI process.
6. Delete `database/create_admin.php` from the live server after creating the administrator.
7. Visit the site, sign in at `/admin/login.php`, create a test shipment, and try its tracking number on the public tracking form.
8. Submit a test quote request and contact message. Check the dashboard to confirm the records are stored.

## Local testing
From the project root, configure `config.php`, import the schema, and create an admin. Then run:
`php -S 127.0.0.1:8000 -t public`
Open `http://127.0.0.1:8000`.

## Important production steps
- Use HTTPS and keep PHP/MySQL patched.
- Use a strong unique admin password and limit administrator access.
- Back up the database and test restores.
- Add rate limiting and login lockout before public launch.
- Configure server-side error logging; do not display raw database errors to visitors.
- Add your real company email, telephone, service coverage, terms, and privacy policy.
- This starter saves quote requests and contact messages in the database but does not email alerts. Configure a mail service if email notifications are required.
- The public tracking page intentionally shows shipment route, service, status, estimated delivery, and tracking events only. Do not add sensitive customer personal information to the public tracking view.
- The system generates internal tracking references; these are not carrier-issued or externally verifiable tracking numbers unless you integrate an actual carrier API.
- Customer accounts, payment processing, carrier API integrations, document uploads, and automated notifications are not included in this starter.

## Security notes
The app uses PDO prepared statements, password hashing, session regeneration after login, HTML escaping, and CSRF tokens on POST forms. This is a starter platform, not a substitute for a professional security review before handling real customer or shipment data.
