<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
function result_page(string $title, string $message, string $link = 'index.php'): never {
    http_response_code(200);
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . e($title) . '</title><style>body{font:16px/1.6 Arial;background:#f4f7fb;color:#172334;margin:0;padding:35px}.box{max-width:650px;margin:7vh auto;background:white;padding:30px;border-radius:15px;box-shadow:0 15px 40px #0b234115}h1{color:#0b2341}a{display:inline-block;background:#ff7a1a;color:white;padding:11px 16px;border-radius:8px;text-decoration:none;font-weight:bold}</style><div class="box"><h1>' . e($title) . '</h1><p>' . e($message) . '</p><a href="' . e($link) . '">Continue</a></div></html>';
    exit;
}
