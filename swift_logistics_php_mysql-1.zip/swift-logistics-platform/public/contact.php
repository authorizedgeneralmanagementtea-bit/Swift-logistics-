<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php#contact');
verify_csrf();
$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$subject = trim((string)($_POST['subject'] ?? ''));
$message = trim((string)($_POST['message'] ?? ''));
if ($name === '' || !valid_email($email) || $subject === '' || $message === '') {
    require __DIR__ . '/result.php';
    result_page('Check your details', 'Please complete all required fields and enter a valid email address.', 'index.php#contact');
}
$stmt = db()->prepare('INSERT INTO contact_messages (name,email,subject,message) VALUES (?,?,?,?)');
$stmt->execute([$name, $email, $subject, $message]);
require __DIR__ . '/result.php';
result_page('Message received', 'Thank you. Your message has been saved for the team to review.', 'index.php');
