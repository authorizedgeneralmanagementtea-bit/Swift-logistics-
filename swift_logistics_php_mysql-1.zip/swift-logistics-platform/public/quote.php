<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php#quote');
verify_csrf();
$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$phone = trim((string)($_POST['phone'] ?? ''));
$service = trim((string)($_POST['service'] ?? ''));
$origin = trim((string)($_POST['origin'] ?? ''));
$destination = trim((string)($_POST['destination'] ?? ''));
$weight = trim((string)($_POST['weight_volume'] ?? ''));
$ready = trim((string)($_POST['ready_date'] ?? ''));
$details = trim((string)($_POST['details'] ?? ''));
if ($name === '' || !valid_email($email) || $service === '' || $origin === '' || $destination === '') {
    require __DIR__ . '/result.php';
    result_page('Check your details', 'Please complete the required fields and enter a valid email address.', 'index.php#quote');
}
if ($ready !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $ready)) $ready = '';
$stmt = db()->prepare('INSERT INTO quote_requests (name,email,phone,service,origin,destination,weight_volume,ready_date,details) VALUES (?,?,?,?,?,?,?,?,?)');
$stmt->execute([$name, $email, $phone ?: null, $service, $origin, $destination, $weight ?: null, $ready ?: null, $details ?: null]);
require __DIR__ . '/result.php';
result_page('Quote request received', 'Thank you. Your request has been saved. It is not a confirmed price or booking; our team must review it and contact you.', 'index.php');
