<?php
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_admin();
$pdo = db();
$statuses = ['Registered','Picked Up','In Transit','At Destination Facility','Out for Delivery','Delivered','On Hold','Exception','Cancelled'];
$services = ['Road Freight','Air Freight','Ocean Freight','Warehousing & Distribution','Supply Chain Management','Import & Export Support','Other'];
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$shipment = null;
if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM shipments WHERE id = ?');
    $stmt->execute([$id]);
    $shipment = $stmt->fetch();
    if (!$shipment) { flash('error','Shipment not found.'); redirect('dashboard.php'); }
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'create') {
        $data = [
            trim((string)($_POST['sender_name'] ?? '')), trim((string)($_POST['sender_email'] ?? '')),
            trim((string)($_POST['sender_phone'] ?? '')), trim((string)($_POST['recipient_name'] ?? '')),
            trim((string)($_POST['recipient_email'] ?? '')), trim((string)($_POST['recipient_phone'] ?? '')),
            trim((string)($_POST['origin'] ?? '')), trim((string)($_POST['destination'] ?? '')),
            trim((string)($_POST['service'] ?? '')), trim((string)($_POST['cargo_description'] ?? '')),
            trim((string)($_POST['weight_volume'] ?? '')), trim((string)($_POST['estimated_delivery'] ?? ''))
        ];
        if ($data[0] === '' || $data[3] === '' || $data[6] === '' || $data[7] === '' || !in_array($data[8], $services, true)) {
            $error = 'Please complete sender, recipient, origin, destination, and service fields.';
        } elseif (($data[1] && !valid_email($data[1])) || ($data[4] && !valid_email($data[4]))) {
            $error = 'Enter valid sender and recipient email addresses, or leave them blank.';
        } else {
            $tracking = generate_tracking_number($pdo);
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare('INSERT INTO shipments (tracking_number,sender_name,sender_email,sender_phone,recipient_name,recipient_email,recipient_phone,origin,destination,service,cargo_description,weight_volume,estimated_delivery) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
                $stmt->execute([$tracking,$data[0],$data[1] ?: null,$data[2] ?: null,$data[3],$data[4] ?: null,$data[5] ?: null,$data[6],$data[7],$data[8],$data[9] ?: null,$data[10] ?: null,$data[11] ?: null]);
                $newId = (int)$pdo->lastInsertId();
                $event = $pdo->prepare('INSERT INTO tracking_events (shipment_id,status,location,notes,created_by) VALUES (?,?,?,?,?)');
                $event->execute([$newId,'Registered',$data[6],'Shipment record created.',(int)$_SESSION['admin_id']]);
                $pdo->commit();
                flash('success','Shipment created. Tracking number: ' . $tracking);
                redirect('shipment.php?id=' . $newId);
            } catch (Throwable $e) {
                $pdo->rollBack();
                $error = 'The shipment could not be saved. Check database configuration and try again.';
            }
        }
    } elseif ($action === 'update' && $id) {
        $status = (string)($_POST['status'] ?? '');
        $location = trim((string)($_POST['location'] ?? ''));
        $notes = trim((string)($_POST['notes'] ?? ''));
        $estimated = trim((string)($_POST['estimated_delivery'] ?? ''));
        if (!in_array($status, $statuses, true) || $location === '') {
            $error = 'Choose a valid status and enter the current location.';
        } elseif ($estimated !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $estimated)) {
            $error = 'Enter a valid estimated delivery date.';
        } else {
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare('UPDATE shipments SET status=?, estimated_delivery=? WHERE id=?');
                $stmt->execute([$status, $estimated ?: null, $id]);
                $stmt = $pdo->prepare('INSERT INTO tracking_events (shipment_id,status,location,notes,created_by) VALUES (?,?,?,?,?)');
                $stmt->execute([$id,$status,$location,$notes ?: null,(int)$_SESSION['admin_id']]);
                $pdo->commit();
                flash('success','Shipment status and tracking history updated.');
                redirect('shipment.php?id=' . $id);
            } catch (Throwable $e) {
                $pdo->rollBack();
                $error = 'Could not update shipment. Please try again.';
            }
        }
        $stmt = $pdo->prepare('SELECT * FROM shipments WHERE id=?');
        $stmt->execute([$id]); $shipment = $stmt->fetch();
    }
}
$flash = take_flash();
$events = [];
if ($shipment) {
    $stmt = $pdo->prepare('SELECT status,location,notes,event_time FROM tracking_events WHERE shipment_id=? ORDER BY event_time DESC,id DESC');
    $stmt->execute([$id]); $events = $stmt->fetchAll();
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= $shipment ? 'Manage Shipment' : 'Create Shipment' ?> | Swift Logistics</title><style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172334;font:15px/1.5 Arial}.bar{background:#0b2341;color:white;padding:16px 22px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap}.bar a{color:#ffb37d}.wrap{max-width:1000px;margin:25px auto;padding:0 16px}.panel{background:white;padding:24px;border-radius:14px;margin-bottom:18px;box-shadow:0 8px 25px #0b23410a}h1,h2{color:#0b2341}.grid{display:grid;grid-template-columns:1fr 1fr;gap:0 16px}.field{margin:10px 0}.field label{display:block;font-weight:bold;margin-bottom:5px}input,select,textarea{width:100%;padding:11px;border:1px solid #d4deea;border-radius:8px;font:inherit}textarea{min-height:90px}.btn{background:#ff7a1a;color:white;padding:11px 15px;border:0;border-radius:8px;font-weight:bold;cursor:pointer;text-decoration:none;display:inline-block}.btn.secondary{background:#0b2341}.notice{padding:12px;border-radius:8px;background:#fff1df;margin:12px 0}.event{border-left:3px solid #ff7a1a;padding:0 0 14px 14px;margin-left:6px}.muted{color:#64748b}@media(max-width:600px){.grid{grid-template-columns:1fr}}</style></head><body><div class="bar"><strong>Swift Logistics Global · Shipment Manager</strong><span><a href="dashboard.php">Dashboard</a> · <a href="logout.php">Log out</a></span></div><div class="wrap">
<?php if ($flash): ?><div class="notice"><?= e($flash['message']) ?></div><?php endif; ?><?php if ($error): ?><div class="notice"><?= e($error) ?></div><?php endif; ?>
<?php if (!$shipment): ?>
<section class="panel"><h1>Create a shipment</h1><p class="muted">A unique tracking number will be generated when the record is saved.</p><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create"><div class="grid">
<div class="field"><label>Sender name *</label><input name="sender_name" required maxlength="160"></div><div class="field"><label>Sender email</label><input name="sender_email" type="email" maxlength="190"></div><div class="field"><label>Sender phone</label><input name="sender_phone" maxlength="50"></div><div class="field"><label>Recipient name *</label><input name="recipient_name" required maxlength="160"></div><div class="field"><label>Recipient email</label><input name="recipient_email" type="email" maxlength="190"></div><div class="field"><label>Recipient phone</label><input name="recipient_phone" maxlength="50"></div><div class="field"><label>Origin *</label><input name="origin" required maxlength="190" placeholder="City, country"></div><div class="field"><label>Destination *</label><input name="destination" required maxlength="190" placeholder="City, country"></div><div class="field"><label>Service *</label><select name="service" required><option value="">Select service</option><?php foreach ($services as $s): ?><option><?= e($s) ?></option><?php endforeach; ?></select></div><div class="field"><label>Weight / volume</label><input name="weight_volume" maxlength="120"></div><div class="field"><label>Estimated delivery</label><input type="date" name="estimated_delivery"></div><div class="field"><label>Cargo description</label><input name="cargo_description" maxlength="2000"></div></div><button class="btn">Create shipment</button> <a class="btn secondary" href="dashboard.php">Cancel</a></form></section>
<?php else: ?>
<section class="panel"><h1>Manage shipment</h1><p><strong>Tracking number:</strong> <?= e($shipment['tracking_number']) ?></p><p><strong>Sender:</strong> <?= e($shipment['sender_name']) ?> · <strong>Recipient:</strong> <?= e($shipment['recipient_name']) ?></p><p><strong>Route:</strong> <?= e($shipment['origin']) ?> → <?= e($shipment['destination']) ?></p><p><strong>Current status:</strong> <?= e($shipment['status']) ?></p><p><a class="btn" href="../track.php?tracking=<?= rawurlencode($shipment['tracking_number']) ?>" target="_blank" rel="noopener">View public tracking</a> <a class="btn secondary" href="dashboard.php">Dashboard</a></p></section>
<section class="panel"><h2>Add tracking update</h2><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update"><div class="grid"><div class="field"><label>Status *</label><select name="status" required><?php foreach ($statuses as $s): ?><option <?= $s === $shipment['status'] ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></div><div class="field"><label>Current location *</label><input name="location" required maxlength="190" placeholder="City, facility, country"></div><div class="field"><label>Estimated delivery</label><input type="date" name="estimated_delivery" value="<?= e($shipment['estimated_delivery']) ?>"></div><div class="field"><label>Notes</label><input name="notes" maxlength="2000" placeholder="Optional update notes"></div></div><button class="btn">Save tracking update</button></form></section>
<section class="panel"><h2>Tracking history</h2><?php if (!$events): ?><p class="muted">No events yet.</p><?php else: foreach ($events as $event): ?><div class="event"><strong><?= e($event['status']) ?></strong><div><?= e($event['location']) ?> · <?= e($event['event_time']) ?></div><?php if ($event['notes']): ?><div class="muted"><?= e($event['notes']) ?></div><?php endif; ?></div><?php endforeach; endif; ?></section>
<?php endif; ?></div></body></html>
