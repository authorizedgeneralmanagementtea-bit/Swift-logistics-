<?php
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
if (!empty($_SESSION['admin_id'])) redirect('dashboard.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $stmt = db()->prepare('SELECT id, name, email, password_hash FROM admins WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $admin = $stmt->fetch();
    if ($admin && password_verify($password, $admin['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int)$admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        redirect('dashboard.php');
    }
    $error = 'Email or password was not recognized.';
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login | Swift Logistics</title><style>body{font:16px Arial;background:#f4f7fb;margin:0;padding:25px}.box{max-width:440px;margin:8vh auto;background:#fff;padding:28px;border-radius:15px;box-shadow:0 15px 40px #0b234115}h1{color:#0b2341}label{display:block;font-weight:bold;margin:15px 0 6px}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #d7e0eb;border-radius:8px}button{margin-top:18px;width:100%;padding:13px;border:0;border-radius:8px;background:#ff7a1a;color:white;font-weight:bold}.error{background:#fff1df;color:#7c3c09;padding:10px;border-radius:7px}</style></head><body><div class="box"><h1>Administrator sign in</h1><p>Swift Logistics Global</p><?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label for="email">Email</label><input id="email" name="email" type="email" required autocomplete="username"><label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password"><button>Sign in</button></form><p><a href="../index.php">← Back to website</a></p></div></body></html>
