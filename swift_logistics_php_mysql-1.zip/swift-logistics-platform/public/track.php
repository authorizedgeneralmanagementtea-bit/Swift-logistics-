<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
$number = strtoupper(trim((string)($_GET['tracking'] ?? '')));
$shipment = null;
$events = [];
if ($number !== '' && strlen($number) <= 40) {
    $stmt = db()->prepare('SELECT tracking_number, origin, destination, service, status, estimated_delivery, created_at, updated_at FROM shipments WHERE tracking_number = ?');
    $stmt->execute([$number]);
    $shipment = $stmt->fetch() ?: null;
    if ($shipment) {
        $ev = db()->prepare('SELECT status, location, notes, event_time FROM tracking_events WHERE shipment_id = (SELECT id FROM shipments WHERE tracking_number = ?) ORDER BY event_time DESC, id DESC');
        $ev->execute([$number]);
        $events = $ev->fetchAll();
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shipment Tracking | Swift Logistics</title><style>
body{margin:0;background:#f4f7fb;color:#172334;font:16px/1.6 Arial}.wrap{width:min(850px,calc(100% - 30px));margin:35px auto}.card{background:white;padding:26px;border-radius:16px;box-shadow:0 15px 40px #0b234115;margin-bottom:18px}h1,h2{color:#0b2341}label{font-weight:bold}input{width:100%;padding:12px;border:1px solid #d7e0eb;border-radius:8px;box-sizing:border-box;margin:8px 0 12px}button,.btn{background:#ff7a1a;color:white;border:0;border-radius:8px;padding:12px 17px;font-weight:bold;cursor:pointer;text-decoration:none;display:inline-block}.pill{display:inline-block;background:#fff0e4;color:#9a4709;padding:5px 10px;border-radius:99px;font-weight:bold}.muted{color:#64748b}.event{border-left:3px solid #ff7a1a;padding:2px 0 16px 16px;margin-left:5px}.event:last-child{padding-bottom:0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.grid div{padding:12px;background:#f8fafc;border-radius:8px}.grid strong{display:block;color:#0b2341}@media(max-width:520px){.grid{grid-template-columns:1fr}}</style></head><body><main class="wrap"><p><a class="btn" href="index.php">← Back to website</a></p><section class="card"><h1>Track a Shipment</h1><form method="get"><label for="tracking">Tracking number</label><input id="tracking" name="tracking" required value="<?= e($number) ?>" placeholder="Enter your tracking number"><button>Track shipment</button></form>
<?php if ($number !== '' && !$shipment): ?><p class="pill">No matching shipment found</p><p class="muted">Check the tracking number and try again. If the issue continues, contact the company using its verified contact details.</p><?php endif; ?>
<?php if ($shipment): ?><hr style="border:0;border-top:1px solid #e2e8f0;margin:22px 0"><p class="muted">Tracking number</p><h2><?= e($shipment['tracking_number']) ?></h2><p><span class="pill"><?= e($shipment['status']) ?></span></p><div class="grid"><div><strong>Origin</strong><?= e($shipment['origin']) ?></div><div><strong>Destination</strong><?= e($shipment['destination']) ?></div><div><strong>Service</strong><?= e($shipment['service']) ?></div><div><strong>Estimated delivery</strong><?= e($shipment['estimated_delivery'] ?: 'Not available') ?></div></div><h2>Tracking history</h2>
<?php if (!$events): ?><p class="muted">No tracking events have been added yet.</p><?php else: foreach ($events as $event): ?><div class="event"><strong><?= e($event['status']) ?></strong><div><?= e($event['location']) ?> · <?= e($event['event_time']) ?></div><?php if ($event['notes']): ?><div class="muted"><?= e($event['notes']) ?></div><?php endif; ?></div><?php endforeach; endif; ?>
<?php endif; ?></section></main></body></html>
