CREATE DATABASE IF NOT EXISTS swift_logistics
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE swift_logistics;

CREATE TABLE IF NOT EXISTS admins (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL,
  phone VARCHAR(50) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_customers_email (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shipments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tracking_number VARCHAR(40) NOT NULL UNIQUE,
  customer_id BIGINT UNSIGNED NULL,
  sender_name VARCHAR(160) NOT NULL,
  sender_email VARCHAR(190) NULL,
  sender_phone VARCHAR(50) NULL,
  recipient_name VARCHAR(160) NOT NULL,
  recipient_email VARCHAR(190) NULL,
  recipient_phone VARCHAR(50) NULL,
  origin VARCHAR(190) NOT NULL,
  destination VARCHAR(190) NOT NULL,
  service VARCHAR(80) NOT NULL,
  cargo_description TEXT NULL,
  weight_volume VARCHAR(120) NULL,
  status ENUM('Registered','Picked Up','In Transit','At Destination Facility','Out for Delivery','Delivered','On Hold','Exception','Cancelled') NOT NULL DEFAULT 'Registered',
  estimated_delivery DATE NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_shipments_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  INDEX idx_shipments_status (status),
  INDEX idx_shipments_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tracking_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  shipment_id BIGINT UNSIGNED NOT NULL,
  status VARCHAR(80) NOT NULL,
  location VARCHAR(190) NOT NULL,
  notes TEXT NULL,
  event_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_events_shipment FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE,
  CONSTRAINT fk_events_admin FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL,
  INDEX idx_events_shipment_time (shipment_id, event_time)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS quote_requests (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL,
  phone VARCHAR(50) NULL,
  service VARCHAR(80) NOT NULL,
  origin VARCHAR(190) NOT NULL,
  destination VARCHAR(190) NOT NULL,
  weight_volume VARCHAR(120) NULL,
  ready_date DATE NULL,
  details TEXT NULL,
  status ENUM('New','Contacted','Quoted','Closed') NOT NULL DEFAULT 'New',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_quotes_status (status),
  INDEX idx_quotes_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS contact_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL,
  subject VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  status ENUM('New','Read','Replied','Archived') NOT NULL DEFAULT 'New',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_messages_status (status)
) ENGINE=InnoDB;
