<?php
// Run once from CLI only: php database/create_admin.php
// Then delete this file from the server.
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Run this script from the command line only.\n");
}
require_once __DIR__ . '/../includes/bootstrap.php';
$name = trim(readline('Administrator name: '));
$email = trim(readline('Administrator email: '));
$password = '';
if (function_exists('shell_exec')) {
    echo "Enter password (input may be visible depending on your terminal): ";
}
$password = trim(readline());
if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12) {
    fwrite(STDERR, "Name/email invalid. Password must be at least 12 characters.\n");
    exit(1);
}
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = db()->prepare('INSERT INTO admins (name, email, password_hash) VALUES (?, ?, ?)');
try {
    $stmt->execute([$name, $email, $hash]);
    echo "Administrator created successfully.\n";
} catch (PDOException $e) {
    fwrite(STDERR, "Could not create admin. The email may already exist or the database setup is incomplete.\n");
    exit(1);
}
